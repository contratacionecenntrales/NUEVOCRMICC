<?php
// Comparador antiguo retirado: los comparadores actuales usan api/cmp_energia.php y api/cmp_telefonia.php.
header('Content-Type: application/json; charset=utf-8');
http_response_code(410);
echo json_encode(['error' => 'El comparador antiguo se ha retirado. Usa el menu Comparador.']);
