/* Comparador antiguo retirado (ya no se carga). Ver js/comparadores.js. */
